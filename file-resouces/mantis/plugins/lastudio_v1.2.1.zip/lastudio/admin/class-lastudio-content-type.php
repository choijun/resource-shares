<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

class LaStudio_Content_Type
{
    /**
     * @var array<string, array>
     */
    protected $postTypes = [];

    /**
     * @var array<string, array>
     */
    protected $taxonomies = [];

    /**
     * Cache template lookups
     *
     * @var array<string, string>
     */
    protected static $templateCache = [];

    public function __construct(
        $postTypes = [],
        $taxonomies = []
    ) {
        $this->postTypes = $postTypes;
        $this->taxonomies = $taxonomies;
    }

    public function setup_filters() {
        $this->postTypes = apply_filters('LaStudio/core/post_type_allow', array(
            'la_block'          => array(
                'label'                 => __( 'Custom Block', 'lastudio' ),
                'supports'              => array( 'title', 'editor'),
                'menu_icon'             => 'dashicons-slides',
                'public'                => true,
                'show_ui'               => true,
                'show_in_menu'          => true,
                'menu_position'         => 6,
                'show_in_admin_bar'     => false,
                'show_in_nav_menus'     => false,
                'can_export'            => true,
                'has_archive'           => false,
                'exclude_from_search'   => true,
                'publicly_queryable'    => false,
                'capability_type'       => 'page'
            ),
            'la_testimonial'    => array(
                'label'                 => __( 'Testimonial', 'lastudio' ),
                'supports'              => array('title'),
                'menu_icon'             => 'dashicons-testimonial',
                'public'                => true,
                'show_ui'               => true,
                'show_in_menu'          => true,
                'menu_position'         => 7,
                'show_in_admin_bar'     => false,
                'show_in_nav_menus'     => false,
                'can_export'            => true,
                'has_archive'           => false,
                'exclude_from_search'   => true,
                'publicly_queryable'    => false,
                'capability_type'       => 'page',
                'rewrite'               => array( 'slug' => 'testimonial' )
            ),
            'la_portfolio'      => array(
                'label'                 => __( 'Portfolio', 'lastudio' ),
                'supports'              => array('title', 'editor', 'thumbnail'),
                'menu_icon'             => 'dashicons-portfolio',
                'public'                => true,
                'menu_position'         => 8,
                'can_export'            => true,
                'has_archive'           => true,
                'exclude_from_search'   => false,
                'rewrite'               => array( 'slug' => 'portfolio' )
            ),
            'la_team_member'    => array(
                'label'                 => __( 'Team Member', 'lastudio' ),
                'supports'              => array('title', 'editor', 'thumbnail'),
                'menu_icon'             => 'dashicons-groups',
                'public'                => true,
                'show_ui'               => true,
                'show_in_menu'          => true,
                'menu_position'         => 8,
                'show_in_admin_bar'     => false,
                'show_in_nav_menus'     => false,
                'can_export'            => true,
                'has_archive'           => false,
                'exclude_from_search'   => true,
                'publicly_queryable'    => true,
                'capability_type'       => 'page',
                'rewrite'               => array( 'slug' => 'team-member' )
            )
        ));
        $this->taxonomies = apply_filters('LaStudio/core/taxonomy_allow', array(
            'la_portfolio_category' => array(
                'post_type' => 'la_portfolio',
                'args'  => array(
                    'hierarchical'      => true,
                    'show_in_nav_menus' => true,
                    'labels'            => array(
                        'name'          => __( 'Portfolio Categories', 'lastudio' ),
                        'singular_name' => __( 'Portfolio Category', 'lastudio' )
                    ),
                    'query_var'         => true,
                    'show_admin_column' => true,
                    'rewrite'           => array('slug' => 'portfolio-category')
                )
            ),
            'la_portfolio_skill' => array(
                'post_type' => 'la_portfolio',
                'args'  => array(
                    'hierarchical'      => true,
                    'show_in_nav_menus' => true,
                    'labels'            => array(
                        'name'          => __( 'Portfolio Skills', 'lastudio' ),
                        'singular_name' => __( 'Portfolio Skill', 'lastudio' )
                    ),
                    'query_var'         => true,
                    'show_admin_column' => true,
                    'rewrite'           => array('slug' => 'portfolio-skill')
                )
            )
        ));
    }
    /**
     * Register CPTs + Taxonomies
     */
    public function register_content_type()
    {
        $this->registerPostTypes();
        $this->registerTaxonomies();
    }

    /**
     * Register post types
     */
    protected function registerPostTypes()
    {
        if ( empty($this->postTypes) ) {
            return;
        }

        foreach ( $this->postTypes as $postType => $args ) {

            if ( empty($postType) || ! is_array($args) ) {
                continue;
            }

            register_post_type(
                sanitize_key($postType),
                $args
            );
        }
    }

    /**
     * Register taxonomies
     */
    protected function registerTaxonomies()
    {
        if ( empty($this->taxonomies) ) {
            return;
        }

        foreach ( $this->taxonomies as $taxonomy => $config ) {

            if (
                empty($taxonomy) ||
                empty($config['post_type']) ||
                empty($config['args'])
            ) {
                continue;
            }

            register_taxonomy(
                sanitize_key($taxonomy),
                $config['post_type'],
                $config['args']
            );
        }
    }

    /**
     * Single template loader
     */
    public function single_template($template)
    {
        $object = get_queried_object();

        if (
            ! is_object($object) ||
            empty($object->post_type) ||
            empty($object->post_name)
        ) {
            return $template;
        }

        $postType = sanitize_key($object->post_type);

        if ( ! isset($this->postTypes[$postType]) ) {
            return $template;
        }

        $postName = sanitize_file_name($object->post_name);

        $normalizedType = str_replace('_', '-', $postType);

        $templates = [
            "single-{$postType}-{$postName}.php",
            "single-{$normalizedType}-{$postName}.php",
            "single-{$postType}.php",
            "single-{$normalizedType}.php",
        ];

        $located = $this->locateTemplate($templates);

        return $located ?: $template;
    }

    /**
     * Archive template loader
     */
    public function archive_template($template)
    {
        $postType = get_query_var('post_type');

        $located = $this->detectArchiveTemplate($postType);

        return $located ?: $template;
    }

    /**
     * Taxonomy template loader
     */
    public function taxonomy_template($template)
    {
        $term = get_queried_object();

        if (
            ! is_object($term) ||
            empty($term->taxonomy)
        ) {
            return $template;
        }

        $taxonomy = sanitize_key($term->taxonomy);

        if ( ! isset($this->taxonomies[$taxonomy]) ) {
            return $template;
        }

        $slug = '';

        if ( ! empty($term->slug) ) {
            $slug = sanitize_file_name($term->slug);
        }

        $normalizedTaxonomy = str_replace('_', '-', $taxonomy);

        $templates = [];

        if ( ! empty($slug) ) {

            $decodedSlug = urldecode($slug);

            if ( $decodedSlug !== $slug ) {
                $templates[] = "taxonomy-{$taxonomy}-{$decodedSlug}.php";
                $templates[] = "taxonomy-{$normalizedTaxonomy}-{$decodedSlug}.php";
            }

            $templates[] = "taxonomy-{$taxonomy}-{$slug}.php";
            $templates[] = "taxonomy-{$normalizedTaxonomy}-{$slug}.php";
        }

        $templates[] = "taxonomy-{$taxonomy}.php";
        $templates[] = "taxonomy-{$normalizedTaxonomy}.php";

        if(in_array($term->taxonomy, array('la_portfolio_category', 'la_portfolio_skill'), true)){
            $templates[] = "archive-la_portfolio.php";
            $templates[] = "archive-la-portfolio.php";
        }

        /**
         * Allow external template injection
         */
        $templates = apply_filters(
            'lastudio/taxonomy_templates',
            $templates,
            $taxonomy,
            $term
        );

        $located = $this->locateTemplate($templates);

        return $located ?: $template;
    }

    /**
     * Detect archive template
     *
     * @param string|array|null $postType
     */
    protected function detectArchiveTemplate($postType)
    {
        if ( empty($postType) ) {
            return null;
        }

        if ( is_array($postType) ) {

            foreach ( $postType as $type ) {

                $template = $this->detectArchiveTemplate($type);

                if ( ! empty($template) ) {
                    return $template;
                }
            }

            return null;
        }

        $postType = sanitize_key((string) $postType);

        if ( ! isset($this->postTypes[$postType]) ) {
            return null;
        }

        $normalizedType = str_replace('_', '-', $postType);

        $templates = [
            "archive-{$postType}.php",
            "archive-{$normalizedType}.php",
        ];

        return $this->locateTemplate($templates);
    }

    /**
     * Locate template with cache
     */
    protected function locateTemplate(array $templates): ?string
    {
        $cacheKey = md5(wp_json_encode($templates));

        if ( isset(self::$templateCache[$cacheKey]) ) {
            return self::$templateCache[$cacheKey];
        }

        $template = locate_template($templates);

        if (
            ! empty($template) &&
            is_readable($template)
        ) {
            self::$templateCache[$cacheKey] = $template;

            return $template;
        }

        self::$templateCache[$cacheKey] = '';

        return null;
    }
}