<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

class LaStudio_PostType
{
    /**
     * @var array<string, array>
     */
    protected $postTypes = [];

    /**
     * @var array<string, array>
     */
    protected $taxonomies = [];

    /**
     * Cache template lookups
     *
     * @var array<string, string>
     */
    protected static $templateCache = [];

    public function __construct(
        $postTypes = [],
        $taxonomies = []
    ) {
        $this->postTypes = $postTypes;
        $this->taxonomies = $taxonomies;

        add_action('init', [$this, 'register'], 5);

        add_filter('single_template', [$this, 'singleTemplate'], 20);
        add_filter('archive_template', [$this, 'archiveTemplate'], 20);
        add_filter('taxonomy_template', [$this, 'taxonomyTemplate'], 20);

    }

    /**
     * Register CPTs + Taxonomies
     */
    public function register()
    {
        $this->registerPostTypes();
        $this->registerTaxonomies();
    }

    /**
     * Register post types
     */
    protected function registerPostTypes()
    {
        if ( empty($this->postTypes) ) {
            return;
        }

        foreach ( $this->postTypes as $postType => $args ) {

            if ( empty($postType) || ! is_array($args) ) {
                continue;
            }

            register_post_type(
                sanitize_key($postType),
                $args
            );
        }
    }

    /**
     * Register taxonomies
     */
    protected function registerTaxonomies()
    {
        if ( empty($this->taxonomies) ) {
            return;
        }

        foreach ( $this->taxonomies as $taxonomy => $config ) {

            if (
                empty($taxonomy) ||
                empty($config['post_type']) ||
                empty($config['args'])
            ) {
                continue;
            }

            register_taxonomy(
                sanitize_key($taxonomy),
                $config['post_type'],
                $config['args']
            );
        }
    }

    /**
     * Single template loader
     */
    public function singleTemplate($template)
    {
        $object = get_queried_object();

        if (
            ! is_object($object) ||
            empty($object->post_type) ||
            empty($object->post_name)
        ) {
            return $template;
        }

        $postType = sanitize_key($object->post_type);

        if ( ! isset($this->postTypes[$postType]) ) {
            return $template;
        }

        $postName = sanitize_file_name($object->post_name);

        $normalizedType = str_replace('_', '-', $postType);

        $templates = [
            "single-{$postType}-{$postName}.php",
            "single-{$normalizedType}-{$postName}.php",
            "single-{$postType}.php",
            "single-{$normalizedType}.php",
        ];

        $located = $this->locateTemplate($templates);

        return $located ?: $template;
    }

    /**
     * Archive template loader
     */
    public function archiveTemplate($template)
    {
        $postType = get_query_var('post_type');

        $located = $this->detectArchiveTemplate($postType);

        return $located ?: $template;
    }

    /**
     * Taxonomy template loader
     */
    public function taxonomyTemplate($template)
    {
        $term = get_queried_object();

        if (
            ! is_object($term) ||
            empty($term->taxonomy)
        ) {
            return $template;
        }

        $taxonomy = sanitize_key($term->taxonomy);

        if ( ! isset($this->taxonomies[$taxonomy]) ) {
            return $template;
        }

        $slug = '';

        if ( ! empty($term->slug) ) {
            $slug = sanitize_file_name($term->slug);
        }

        $normalizedTaxonomy = str_replace('_', '-', $taxonomy);

        $templates = [];

        if ( ! empty($slug) ) {

            $decodedSlug = urldecode($slug);

            if ( $decodedSlug !== $slug ) {
                $templates[] = "taxonomy-{$taxonomy}-{$decodedSlug}.php";
                $templates[] = "taxonomy-{$normalizedTaxonomy}-{$decodedSlug}.php";
            }

            $templates[] = "taxonomy-{$taxonomy}-{$slug}.php";
            $templates[] = "taxonomy-{$normalizedTaxonomy}-{$slug}.php";
        }

        $templates[] = "taxonomy-{$taxonomy}.php";
        $templates[] = "taxonomy-{$normalizedTaxonomy}.php";

        if(in_array($term->taxonomy, array('la_portfolio_category', 'la_portfolio_skill'), true)){
            $templates[] = "archive-la_portfolio.php";
            $templates[] = "archive-la-portfolio.php";
        }

        /**
         * Allow external template injection
         */
        $templates = apply_filters(
            'lastudio/taxonomy_templates',
            $templates,
            $taxonomy,
            $term
        );

        $located = $this->locateTemplate($templates);

        return $located ?: $template;
    }

    /**
     * Detect archive template
     *
     * @param string|array|null $postType
     */
    protected function detectArchiveTemplate($postType)
    {
        if ( empty($postType) ) {
            return null;
        }

        if ( is_array($postType) ) {

            foreach ( $postType as $type ) {

                $template = $this->detectArchiveTemplate($type);

                if ( ! empty($template) ) {
                    return $template;
                }
            }

            return null;
        }

        $postType = sanitize_key((string) $postType);

        if ( ! isset($this->postTypes[$postType]) ) {
            return null;
        }

        $normalizedType = str_replace('_', '-', $postType);

        $templates = [
            "archive-{$postType}.php",
            "archive-{$normalizedType}.php",
        ];

        return $this->locateTemplate($templates);
    }

    /**
     * Locate template with cache
     */
    protected function locateTemplate(array $templates): ?string
    {
        $cacheKey = md5(wp_json_encode($templates));

        if ( isset(self::$templateCache[$cacheKey]) ) {
            return self::$templateCache[$cacheKey];
        }

        $template = locate_template($templates);

        if (
            ! empty($template) &&
            is_readable($template)
        ) {
            self::$templateCache[$cacheKey] = $template;

            return $template;
        }

        self::$templateCache[$cacheKey] = '';

        return null;
    }
}